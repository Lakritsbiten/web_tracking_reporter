from simple_tracking.web_site.routes import flask_app


def main():
    # turn on the flask rest service in the main thread
    flask_app.run(debug=True)


if __name__ == '__main__':
    main()